export class GameOverScreen {
  constructor(scene) {
    this.scene = scene;

    const style = {
      fontSize: '48px',
      fill: '#ff0000',
      fontFamily: 'Arial',
      align: 'center',
      stroke: '#000',
      strokeThickness: 4
    };

    this.container = this.scene.add.container(400, 300).setVisible(false);
    this.container.setDepth(1000); // Ensure it's always on top

    const gameOverTitle = this.scene.add.text(0, -60, 'Game Over', style).setOrigin(0.5);
    this.scoreText = this.scene.add.text(0, 20, 'Score: 0', { 
      ...style, 
      fontSize: '32px', 
      fill: '#ffffff',
      stroke: '#000000',
      strokeThickness: 6,
      shadow: {
        offsetX: 2,
        offsetY: 2,
        color: '#000000',
        blur: 4,
        fill: true
      }
    }).setOrigin(0.5);
    const restartText = this.scene.add.text(0, 80, 'Press R to Restart', { 
      ...style, 
      fontSize: '24px', 
      fill: '#ffffff',
      stroke: '#000000',
      strokeThickness: 4
    }).setOrigin(0.5);
    
    this.container.add([gameOverTitle, this.scoreText, restartText]);
  }

  show(score, onRestartCallback) {
    console.log(`[GAMEOVER] Game over screen shown with score: ${score}`);
    console.log(`[GAMEOVER] Score type: ${typeof score}, value: ${score}`);
    
    if (score === undefined || score === null) {
      console.error('[GAMEOVER] Score is undefined or null!');
      score = 0;
    }
    
    this.scoreText.setText('Your Score: ' + score);
    this.container.setVisible(true);
    this.container.setAlpha(0);

    console.log(`[GAMEOVER] Container visible: ${this.container.visible}`);
    console.log(`[GAMEOVER] Score text content: ${this.scoreText.text}`);

    this.scene.tweens.add({
      targets: this.container,
      alpha: 1,
      duration: 500,
      ease: 'Power2'
    });

    this.scene.input.keyboard.once('keydown-R', () => {
      console.log('[GAMEOVER] Restart key pressed');
      onRestartCallback();
    });
  }

  hide() {
    this.container.setVisible(false);
  }
}
